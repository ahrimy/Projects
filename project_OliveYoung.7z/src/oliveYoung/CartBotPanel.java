package oliveYoung;
import javax.swing.JPanel;

public class CartBotPanel extends JPanel{

}
